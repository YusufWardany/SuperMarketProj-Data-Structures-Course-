package com.company;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class GUI extends JFrame implements ActionListener {
    private JButton addBtn, generateReceiptBtn;
    private JTextField itemNameField;
    private JTextArea itemListArea;
    private List<String> itemList;

    public GUI() {
        setTitle("Supermarket Management System");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        itemList = new ArrayList();

        itemNameField = new JTextField(20);
        addBtn = new JButton("Add Item");
        generateReceiptBtn = new JButton("Generate Receipt");

        addBtn.addActionListener(this);
        generateReceiptBtn.addActionListener(this);

        JPanel inputPanel = new JPanel();
        inputPanel.add(new JLabel("Enter Item Name: "));
        inputPanel.add(itemNameField);
        inputPanel.add(addBtn);
        inputPanel.add(generateReceiptBtn);

        itemListArea = new JTextArea(20, 40);
        itemListArea.setEditable(false);

        panel.add(inputPanel, BorderLayout.NORTH);
        panel.add(new JScrollPane(itemListArea), BorderLayout.CENTER);

        add(panel);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addBtn) {
            String itemName = itemNameField.getText().trim();
            if (!itemName.isEmpty()) {
                itemList.add(itemName);
                updateItemListArea();
                itemNameField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "Please enter an item name.");
            }
        } else if (e.getSource() == generateReceiptBtn) {
            generateReceipt();
        }
    }

    private void updateItemListArea() {
        StringBuilder sb = new StringBuilder();
        for (String item : itemList) {
            sb.append(item).append("\n");
        }
        itemListArea.setText(sb.toString());
    }

    private void generateReceipt() {
        StringBuilder receipt = new StringBuilder();
        receipt.append("Supermarket Receipt:\n\n");
        for (int i = 0; i < itemList.size(); i++) {
            receipt.append((i + 1)).append(". ").append(itemList.get(i)).append("\n");
        }
        JOptionPane.showMessageDialog(this, receipt.toString());
    }}