package com.company;
import java.util.LinkedList;

public class Grocery extends Product{
    private double pricePerKilo ;
    private String productionDate;

    private LinkedList<Grocery> fruits;
    private LinkedList<Grocery> vegetables;
    public Grocery(){
        super() ;
        this.fruits = new LinkedList();
        this.vegetables = new LinkedList() ;
    }

    public Grocery(String productName ,String Id,String expiryDate, String productionCountry ,String supplierInformation,
                    double pricePerKilo, String productionDate
    ) {
        super(productName ,Id,expiryDate, productionCountry , supplierInformation);
        this.pricePerKilo = pricePerKilo;
        this.productionDate = productionDate;

    }


    public void setPricePerKilo(double pricePerKilo) {
        this.pricePerKilo = pricePerKilo;
    }

    public void setProductionDate(String productionDate) {
        this.productionDate = productionDate;
    }




    public double getPricePerKilo() {
        return pricePerKilo;
    }

    public String getProductionDate() {
        return productionDate;
    }

    public void addFruitsForMarket(String productName ,String ID, String productionCountry ,
                                   String supplierInformation ,String expiryDate, double pricePerKilo, String productionDate
    ){
        this.fruits.add(new Grocery(productName ,ID, productionCountry , supplierInformation , expiryDate , pricePerKilo ,
                productionDate ));
    }
    public void addVegetablesForMarket(String productName ,String ID, String expiryDate,String productionCountry ,
                                       String supplierInformation , double pricePerKilo, String productionDate
    ) {
        this.vegetables.add(new Grocery(productName,ID,expiryDate,  productionCountry, supplierInformation, pricePerKilo,
                productionDate));
    }
    public void removeFruitsForMarket(String ID ){
        Grocery g = new Grocery() ;
        for(int i = 0 ; i < this.fruits.size() ; i++){
            if(this.fruits.get(i).getID().equalsIgnoreCase(ID)){
                this.fruits.remove(i) ;
            }
        }
    }
    public void removeVegetablesForMarket(String ID ){
        Grocery g = new Grocery() ;
        for(int i = 0 ; i < this.vegetables.size() ; i++){
            if(this.vegetables.get(i).getID().equalsIgnoreCase(ID)){
                this.vegetables.remove(i) ;
            }
        }

    }
    public void displayFruits(){
        System.out.println("Fruits :-");
        for(int i = 0 ; i < this.fruits.size() ; i++){
            System.out.println("Item : "+(i+1)+" :");
            System.out.println("Product Name : "+this.fruits.get(i).getProductName()+"\n"
                    +"Production Country : "+this.fruits.get(i).getProductionCountry()+"\n"
                    +"Supplier Information : "+this.fruits.get(i).getSupplierInformation()+"\n"
                    +"Production Date : "+this.fruits.get(i).getProductionDate()+"\n"
                    +"Expiry Date : "+this.fruits.get(i).getExpiryDate()+"\n"
                    +"Price Per Kilo : "+this.fruits.get(i).getPricePerKilo() );
        }

    }
    public void displayVegetables(){
        System.out.println("Vegetables:- ");
        for(int i = 0 ; i < this.vegetables.size() ; i++){
            System.out.println("Item : "+(i+1)+" :");
            System.out.println("Product Name : "+this.vegetables.get(i).getProductName()+"\n"
                    +"Production Country : "+this.vegetables.get(i).getProductionCountry()+"\n"
                    +"Supplier Information : "+this.vegetables.get(i).getSupplierInformation()+"\n"
                    +"Production Date : "+this.vegetables.get(i).getProductionDate()+"\n"
                    +"Expiry Date : "+this.vegetables.get(i).getExpiryDate()+"\n"
                    +"Price Per Kilo : "+this.vegetables.get(i).getPricePerKilo() );
        }

    }
    public void displayFruitsAndVegetables(){
        displayFruits();
        displayVegetables();
    }

    public LinkedList<Grocery> getFruits() {
        return fruits;
    }

    public void setFruits(LinkedList<Grocery> fruits) {
        this.fruits = fruits;
    }

    public LinkedList<Grocery> getVegetables() {
        return vegetables;
    }

    public void setVegetables(LinkedList<Grocery> vegetables) {
        this.vegetables = vegetables;
    }
}
