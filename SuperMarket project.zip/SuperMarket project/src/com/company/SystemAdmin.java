package com.company;
public class SystemAdmin {


    public void addProductToDepository(Depository depository, Product product, int quantity,String ID) {
        depository.updateProduct(product.getProductName(), quantity);
        System.out.println("Added " + quantity + " " + product.getProductName() + " to the depository.");
    }

    public void removeProductFromDepository(Depository depository, Product product, int quantity,String ID) {
        try {
            depository.removeProduct(product.getProductName(), quantity);
            System.out.println("Removed " + quantity + " " + product.getProductName()+ " from the depository.");
        } catch (IllegalArgumentException e) {
            System.out.println("Failed to remove " + quantity + " " + product.getProductName()
                    + " from the depository: " + e.getMessage());
        }
    }


    }

