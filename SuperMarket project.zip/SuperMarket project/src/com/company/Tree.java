package com.company;
import java.util.LinkedList;
import java.util.Queue;

public class Tree  {
    public TreeNode root ;
    public Tree(){
        this.root =  null ;
    }
    public TreeNode getRoot(){
        return  this.root ;
    }
    public void preorder(TreeNode tree_node){
        if(tree_node == null)
            return ;
        System.out.println(tree_node.data+" ");
        preorder(tree_node.left);
        preorder(tree_node.right);

    }
    public void printLevelOrder(TreeNode root){
        Queue<TreeNode> queue = new LinkedList() ;
        queue.add(root) ;
        while(!queue.isEmpty()){
            TreeNode temp = queue.poll() ;
            System.out.println(temp.data+" ");
            if(temp.left != null){
                queue.add(temp.left) ;
            }
            if(temp.right != null){
                queue.add(temp.right) ;
            }
        }
    }
}
