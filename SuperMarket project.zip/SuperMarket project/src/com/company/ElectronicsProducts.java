package com.company;

import java.util.ArrayList;

public class ElectronicsProducts extends Product{
    private String expiryDate;
    private double ElectronicsPrice ;
    private String productionDate;

    private ArrayList<ElectronicsProducts> Electronics;
    public ElectronicsProducts(){
        super();
        this.Electronics=new ArrayList();
    }

    public ElectronicsProducts(String productName,String ID, String productionCountry,
                               String supplierInformation,String expiryDate, String productionDate,double price) {
        super(productName,ID, productionCountry, supplierInformation);
        this.expiryDate=expiryDate;
        this.productionDate = productionDate;
        this.ElectronicsPrice=price;
    }


    public String getExpiryDate() {
        return expiryDate;
    }

    public double getElectronicsPrice() {
        return ElectronicsPrice;
    }

    public String getProductionDate() {
        return productionDate;
    }

    public ArrayList<ElectronicsProducts> getElectronics() {
        return Electronics;
    }

    public void addElectronicsProduct(String productName,String ID, String productionCountry,
                                      String supplierInformation,String expiryDate, String productionDate,double price) {
        {
          this.Electronics.add(new ElectronicsProducts( productName,ID,  productionCountry,
                  supplierInformation, expiryDate,  productionDate, price));
        }
//        public void removeElectronicsProduct(String ID)
//        {
//            Grocery g = new Grocery() ;
//            for(int i = 0 ; i < this.Electronics.size() ; i++){
//                if(this.Electronics.get(i).getID().equalsIgnoreCase(ID)){
//                    this.Electronics.remove(i) ;
//                }
//            }
//
//    }


    }
}
