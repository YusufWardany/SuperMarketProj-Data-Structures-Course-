//package com.company;
//
//import java.util.LinkedList;
//import java.util.Queue;
//import java.util.Stack;
//
//public class SupermarketOperations extends  Product{
//    private Queue<Product> productQueue;
//    private Stack<Product> productStack;
//
//    public SupermarketOperations() {
//        productQueue = new LinkedList<Product>();
//        productStack = new Stack();
//    }
//
//    public void enqueueProduct(Product product) {
//        productQueue.add(product);
//    }
//
//    public Product dequeueProduct() {
//        return productQueue.poll();
//    }
//
//    public void pushProduct(Product product) {
//        productStack.push(product);
//    }
//
//    public Product popProduct() {
//        return productStack.pop();
//    }
//
//    public boolean isQueueEmpty() {
//        return productQueue.isEmpty();
//    }
//
//    public boolean isStackEmpty() {
//        return productStack.isEmpty();
//    }
//
//    //using queues to sell the products that have the oldest expiry date first then the new one
//    public void sellProductsUsingQueue() {
//        while (!isQueueEmpty()) {
//            Product product = dequeueProduct();
//            System.out.println("Selling product: " + product.getProductName() + " (Expiry date: " + product.getExpiryDate() + ")");
//        }
//    }
//
//
//    //using stacks to store the products that have the newest expiry date to sell them in the last
//    public void sellProductsUsingStack() {
//        while (!isStackEmpty()) {
//            Product product = popProduct();
//            System.out.println("Selling product: " + product.getProductName() + " (Expiry date: " + product.getExpiryDate() + ")");
//        }
//
//    }
//
//    /* using stacks to store the products that have the newest expiry date to
//        sell them in the last by moving them to a queue and then enqueue them */
//
//    public static void moveProductsFromStackToQueue(Stack<Product> productStack, Queue<Product> productQueue) {
//        while (!productStack.isEmpty()) {
//            Product product = productStack.pop();
//            productQueue.add(product);
//        }
//
//
//        // Push products to the stack
//        productStack.push(new Product());
//        productStack.push(new Product());
//        productStack.push(new Product());
//
//        // Move products from stack to queue
//        moveProductsFromStackToQueue(productStack, productQueue);
//
//        // Display the products in the queue
//        while (!productQueue.isEmpty()) {
//            Product product = productQueue.poll();
//            System.out.println("Product: " + product.getProductName());
//        }
//
//
//    }
//
//}

