package com.company;
import java.util.ArrayList;
import java.util.LinkedList ;
import java.util.Scanner ;
import java.util.concurrent.Callable;

public class Customer extends  User{
    public LinkedList<Customer> customers ;
    public LinkedList<Product> cart ;
    Receipt receipt=new Receipt();
    Product product=new Product();
    public Customer(){
        this.customers = new LinkedList();
        this.cart = new LinkedList() ;
    }

    public Customer(String firstName, String lastName, String phoneNumber, String email, String userName, String password) {
        super(firstName, lastName, phoneNumber, email, userName, password);
    }
    public void createAccount(String firstName, String lastName, String phoneNumber, String email,
                              String userName, String password){
        Customer newCustomer = new Customer() ;
        newCustomer.setFirstName(firstName);
        newCustomer.setLastName(lastName);
        newCustomer.setEmail(email);
        newCustomer.setPhoneNumber(phoneNumber);
        newCustomer.setPassword(password);
        newCustomer.setUserName(userName);
        this.customers.add(newCustomer) ;
    }
    public void removeUserByUserName(String userName){
        Customer c = new Customer() ;
        for(int i = 0 ; i < this.customers.size() ; i++){
            if(this.customers.get(i).getUserName().equals(userName)){
                this.customers.remove(i) ;
            }
        }
    }




}

