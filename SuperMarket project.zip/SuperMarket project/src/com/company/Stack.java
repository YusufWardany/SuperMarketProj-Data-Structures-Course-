package com.company;
public class Stack<U> {
    public int top ;
    public int [] stack ;

    public Stack(){
        this.top = -1 ;
        this.stack = new int[1000] ;
    }
    public boolean isEmpty(){
        return this.top < 0 ;

    }
    public void push(int item){
        if(this.top >= this.stack.length - 1 ){
            System.out.println("Stack is full.");
        }
        this.top++ ;
        this.stack[this.top]  = item ;
    }
    public void pop(){
        if(isEmpty() == true){
            System.out.println("Stack is Empty .");
        }
        this.top-- ;

    }
    //REVISE THIS METHOD AGAIN
    public int pop(int Element){
        if(isEmpty() == true){
            System.out.println("Stack is Empty .");
        }
        Element = this.stack[this.top] ;
        this.top--;
        return Element ;
    }
    public int peek(){
        return this.stack[this.top] ;
    }
    public void printElementsInStack(){
        for(int i = this.top ; i >=0 ; i--){
            System.out.print(this.stack[i]+" ");

        }
        System.out.println();
    }


}
