package com.company;


//Yusuf yasser said wardany
//ID:22100809
public class Main {
    public static void main(String[] args) {


//Problems :

        //Adding & remove products

        //class product - - > displayProducts function - - > should display all the market products


        /* class receipt - - > addProduct to cart menu - - > elements that have been added
         . . should be stored in products arraylist to print them in the receipt soon
         . . and they should be removed from products arraylists in their classes */


        /* When adding a product - - > addProductToCart method - - > in the receipt class . .
              we should add a product with the quantity per kilo . .
              and the (remove should be with the quantity - - > and subtract this quantity from the original quantity)  */

        /* when we adding a product from Depository . .
            it should be automatically added to the suitable class and list of its type */


        /* Linking all the classes with each other . .
             and store all the products from all types in a one list to display all the market contents */

       // . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

//Should be created :

        //Login function should search for a users if they are in the list by BST . .  and

        //using queues to sell the products that have the oldest expiry date first then the new one

        //using stacks to store the products that have the newest expiry date to sell them in the last

        //using linkedList methods on the Grocery class

        //make a better GUI

        // . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

     Customer customer1=new Customer("Yusuf","Yasser","0122",
             "Yusuf.com","YusufYasser","1234");
     Product product1=new Product();
     Product product2=new Product();
     Depository depository1=new Depository();
     Receipt receipt1=new Receipt();
     MeatProducts meatProducts1=new MeatProducts();
     User user1=new User();


     Tree tree=new Tree();
     TreeNode treeNode=new TreeNode();
     Node node=new Node();

        //the Stack arranged operations
        Stack <Customer> Customer_stack = new Stack<Customer>();
        Stack <Cashier> Cashier_stack = new Stack<Cashier>();
        Stack <Receipt> receiptStack_stack = new Stack<Receipt>();



        //the queue operations products arranged
        LinkedQueue<MeatProducts> meat_queue = new LinkedQueue<MeatProducts>();
        LinkedQueue<Product> product_queue = new LinkedQueue<Product>();
        LinkedQueue<Clothes> cloth_queue = new LinkedQueue<Clothes>();


        //Linked list operations
        LinkedList<Grocery> fruit1=new LinkedList<Grocery>();
        LinkedList<Grocery> veg1=new LinkedList<Grocery>();

        //BST operations
        BinarySearchTree<User> userBinarySearchTree=new BinarySearchTree<User>();







        //System.out.println(meatProducts1.getProductName());;
        //System.out.println();
     //meatProducts1.displayProducts();
       // System.out.println();

     //user1.LoginFunc();
     receipt1.addProductToCart();

        product1.setProductName("banana");
        product1.setPrice(1000);
         product2.setProductName("apple");
         product2.setPrice(1500);
         receipt1.addProduct(product1);
         receipt1.calculateTotalAmount();
         receipt1.printReceipt();


         Cashier cashier1=new Cashier("Ali","mo","011","ali@",
                 "Ali","1234",12);


        GUI s=new GUI();

    }



}







