package com.company;

public class Node {
    public char value ;
    public Node next ;//reference to next node ;

    public Node(){

    }
    public Node(char value){
        this.value = value  ;

    }

    public void setValue(char value) {
        this.value = value;
    }

    public char getValue(){
        return value ;
    }
    public Node getNext(){
        return next ;
    }
}
