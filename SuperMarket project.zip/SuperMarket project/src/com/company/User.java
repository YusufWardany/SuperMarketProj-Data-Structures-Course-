package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class User {
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String email;
    private String userName;
    private String password;
    private int ID;

    public User() {

    }

    public User(String firstName, String lastName, String phoneNumber, String email, String userName, String password) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.userName = userName;
        this.password = password;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

public static void LoginFunc(){

            Scanner scanner = new Scanner(System.in);
            while (true) {
                System.out.println("Welcome to the Supermarket System!");
                System.out.println("1. Login");
                System.out.println("2. Register");
                System.out.println("3. Exit");
                System.out.print("Enter your choice: ");

                int choice = getUserChoice(scanner); // Call function for user input

                switch (choice) {

                    case 1:
                        System.out.print("Enter user name:");
                        String userName=scanner.next();
                        System.out.print("Enter password:");
                        String Password=scanner.next();
                        //handle the login
                        System.out.println("Login functionality in progress...");
                        // Replace with your actual login implementation


                        break;
                    case 2:
                        // Handle registration logic here
                        System.out.println("Registration functionality in progress...");
                        // Replace with your actual registration implementation
                        System.out.println("Enter your first name : ");
                        String new_Fname = scanner.next();
                        System.out.println("Enter your Second name : ");
                        String new_Lname = scanner.next();
                        System.out.println("Enter your phone number : ");
                        String new_phone = scanner.next();
                        System.out.println("Enter your  email : ");
                        String new_email = scanner.next();
                        System.out.println("Enter your user name : ");
                        String new_username = scanner.next();
                        System.out.println("Enter your user password :");
                        String new_pass = scanner.next();
                        BinarySearchTree<Customer> new_customer= new BinarySearchTree<Customer>();
                        Customer new_cus= new Customer(new_Fname, new_Lname,new_phone,new_email, new_username,new_pass );

                        break;
                    case 3:
                        System.out.println("Exiting the system...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }

                if (choice == 3) {
                    return;
                }
            }


        }

        public static int getUserChoice(Scanner scanner) {
            String input = scanner.nextLine();
            try {
                return Integer.parseInt(input); // Convert input to integer
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number (1-3).");
                return getUserChoice(scanner); // Recursively call for valid input
            }
        }
    }

