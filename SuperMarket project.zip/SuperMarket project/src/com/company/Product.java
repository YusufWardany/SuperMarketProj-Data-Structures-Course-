package com.company;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class Product extends Depository{

    Depository depository=new Depository();

    private String expiryDate;
    private double price;
    private String productName;
    private String productionCountry ;
    private String supplierInformation ;
    private String ID;
    private ArrayList<Product> salesHistory;

    public Product(String productName, String expiryDate) {
        this.productName = productName;
        this.expiryDate = expiryDate;
    }


    public Product(String productName,String ID, String productionCountry, String supplierInformation) {
        this.productName = productName;
        this.ID=ID;
        this.productionCountry = productionCountry;
        this.supplierInformation = supplierInformation;
    }
    public Product(String productName,String ID,String expiryDate, String productionCountry, String supplierInformation) {
        this.productName = productName;
        this.ID=ID;
        this.expiryDate=expiryDate;
        this.productionCountry = productionCountry;
        this.supplierInformation = supplierInformation;
    }
    public Product(){}

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getProductName() {
        return productName;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getProductionCountry() {
        return productionCountry;
    }


    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }



    public String getSupplierInformation() {
        return supplierInformation;
    }

    public ArrayList<Product> getSalesHistory() {
        return salesHistory;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }


    public void setProductionCountry(String productionCountry) {
        this.productionCountry = productionCountry;
    }


    public void setSupplierInformation(String supplierInformation) {
        this.supplierInformation = supplierInformation;
    }

        public double productPrice(Product product) {
            Grocery g1=new Grocery();
            Clothes c1=new Clothes();
            ElectronicsProducts e1=new ElectronicsProducts();
            MeatProducts m1=new MeatProducts();
            if (product.getPrice()==g1.getPricePerKilo() ) {
                return g1.getPrice();
            } else if (product.getPrice()==c1.getPrice() ) {
                return  c1.getPrice();
            } else if (product.getPrice()==e1.getElectronicsPrice() ) {
                return e1.getPrice();
            } else if (product.getPrice()==m1.getMeatPricePerKilo() ) {
                return m1.getPrice();
            } else {
                return product.getPrice(); // Default price for other product types
            }
        }








}





