package com.company;


public class LinkedList<G extends com.company.Product>{
    private Node head ;
    private int size ;

    public LinkedList(){

        this.head = null ;
        this.size = 0 ;
    }

    public void appendLinkedList(LinkedList<com.company.Product> l) {
        Node current = this.head ;
        while(current.next != null){
            current = current.next ;
        }
        current.next = l.getHead() ;
    }
    public void addFirst(char info){
        Node newnode = new Node() ;
        newnode.value = info ;
        if(this.head == null){
            newnode.next = null ;
            head = newnode ;
            this.size++ ;
        }
        else{
            newnode.next = this.head ;
            this.head = newnode ;
            this.size++;
        }
    }
    public void addLast(char info){
        Node newnode = new Node() ;
        newnode.value = info ;
        if(this.head == null){
            newnode.next = null ;
            head = newnode ;
            this.size++ ;
        }
        else{
            Node curr = this.head ;
            while(curr.next != null){
                curr=curr.next ;
            }
            curr.next = newnode ;
            newnode.next = null ;
            this.size++ ;

        }
    }
    public void addAtPosition(int index , char info){
        if(index == 0 ){
            addFirst(info);
        }
        else{
            Node newnode = new Node() ;
            newnode.value = info ;
            Node current = this.head ;
            for(int i = 0 ; i < index - 1 ; i++){
                current = current.next ;
            }
            newnode.next = current.next ;
            current.next= newnode ;
            this.size++;
        }
    }
    public void deleteFirst(){
        this.head = this.head.next ;
        this.size-- ;
    }
    public void deleteLast(){
        Node current = this.head ;
        while(current.next.next != null){
            current = current.next ;
        }
        current.next = null ;
        this.size--;
    }
    public void deleteAtIndex(int index){
        if(index == 0){
            deleteFirst();
        }
        else if(index == this.size - 1){
            deleteLast();
        }
        else{
            Node current = this.head ;
            for(int i = 0 ; i < index - 1 ; i++){
                current = current.next ;
            }
            current.next = current.next.next ;
        }

    }
    public char  get(int index){
        Node current = this.head ;
        for(int i = 0 ; i < this.size ; i++){
            if(i == index){
                break ;

            }
        }
        return current.value ;
    }
    public int search(char info){
        Node current = this.head ;
        for(int i = 0 ; i < this.size ;i++){
            if(current.value == info){
                return i ;
            }
        }
        return -1 ; // if item is not found
    }
    public String getMaximum(){
        Node current = this.head ;
        char maximum = 0 ;
        for(int i = 0 ; i < this.size ; i++){
            if( current.value > maximum){
                maximum = current.value ;
            }
        }
        return Character.toString(maximum) ;
    }
    public String getMinimum(){
        Node current = this.head ;
        char minimum = 0 ;
        for(int i = 0 ; i < this.size ; i++){
            if( current.value < minimum){
                minimum = current.value ;
            }
        }
        return Character.toString(minimum) ;
    }


    public int countNodesRecursive(Node current){
        if(current == null)
            return 0 ;
        else
            return 1 + countNodesRecursive(current.next) ;}
    public void deleteAllList(){
        this.head = null ;}
    public void display(){
        Node current = new Node() ;
        current = head ;
        while(current != null){
            System.out.print(current.value+"->");
            current = current.next ;
        }
        System.out.print("NULL");
        System.out.println();
    }
    public int Size() {
        return size;}
    public Node getHead() {
        return head;}
    public void setHead(Node head) {
        this.head = head;}
}
