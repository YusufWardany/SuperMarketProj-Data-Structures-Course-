package com.company;
public class LinkedQueue<M extends com.company.Product>  {
    Node front ;
    Node rear ;
    public LinkedQueue(){
        this.front = null ;
        this.rear = null ;
    }
    public boolean isEmpty(){
        return this.front == null ;
    }
    public void enQueue(char value){
        Node new_node = new Node() ;
        new_node.value = value ;
        if(this.rear == null){
            this.front = this.rear = new_node ;
        }
        else{
            this.rear.next = new_node ;
            this.rear = new_node ;
        }
    }
    public void deQueue(){
        if(isEmpty() == true){
            System.out.println("The queue is empty , cant delete elements .");
        }
        else if(this.front == this.rear){
            this.front = this.rear = null ;
        }
        Node new_node = this.front ;
        this.front = this.front.next ;
        if(this.front == null){
            this.rear = null ;
        }
    }
    public Object  peek(){
        return this.front.value ;

    }
    public void display(){
        if(isEmpty() == true){
            System.out.println("The queue is empty .");
        }
        else{
            Node current = this.front ;
            while ( current != this.rear.next){
                System.out.print(current.value+" ");
                current = current.next ;

            }
            System.out.println();
        }

    }

    public void add(MeatProducts meatProducts) {
    }


}

