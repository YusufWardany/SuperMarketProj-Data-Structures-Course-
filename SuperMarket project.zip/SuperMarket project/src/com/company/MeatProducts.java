package com.company;
import java.util.ArrayList;
import  java.util.LinkedList ;
public class MeatProducts extends  Product{
    private double MeatPricePerKilo;
    private LinkedQueue meatProducts;
    public MeatProducts(){
        super();
        this.meatProducts = new LinkedQueue();
    }


    public MeatProducts(String productName,String Id,String expiryDate, String productionCountry, String supplierInformation, double pricePerKilo) {
        super(productName,expiryDate,Id, productionCountry, supplierInformation);

        this.MeatPricePerKilo = pricePerKilo;
    }

    public double getMeatPricePerKilo() {
        return MeatPricePerKilo;
    }

    public LinkedQueue getMeatProducts() {
        return meatProducts;
    }


    public void setPricePerKilo(double pricePerKilo) {
        this.MeatPricePerKilo = pricePerKilo;
    }
    public void addMeatProduct(String productName,String ID,String expiryDate,String productionCountry,
                               String supplierInformation, double pricePerKilo){
        this.meatProducts.add(new MeatProducts(productName,ID,expiryDate,productionCountry,supplierInformation,pricePerKilo));
    }

//    public void removeMeatProduct(String ID){
//        MeatProducts m=new MeatProducts();
//        for(int i = 0 ; i < this.meatProducts.size() ; i++){
//            if(this.meatProducts.get(i).g){
//                this.meatProducts.remove(i) ;
//            }
//        }
//    }

}
