package com.company;
public class TreeNode {
    public int data ;
    public TreeNode right ;
    public TreeNode left ;
    public TreeNode( int data ){
        this.data = data ;
    }
    public TreeNode(){
        this.right = this.left = null ;
    }

}
