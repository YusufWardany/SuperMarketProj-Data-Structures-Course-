package com.company;
import java.util.ArrayList;
import java.util.List;

public class Cashier extends User {
    private List<Product> scannedItems;
    private int id;

    public Cashier(String firstName, String lastName,
                   String phoneNumber, String email, String userName, String password,int id) {
        super(firstName, lastName, phoneNumber, email, userName, password);
        this.id=id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double scanItem(Product product) {
        // Simulate scanning the item and adding it to the list of scanned items
        scannedItems.add(product);
        return product.getPrice();
    }

    public double calculateTotalAmount() {
        double totalAmount = 0.0;
        for (Product product : scannedItems) {
            totalAmount +=  product.getPrice();
        }
        return totalAmount;
    }

    public double processPayment(double totalAmount, double paymentAmount) {
        if (paymentAmount >= totalAmount) {
            double change = paymentAmount - totalAmount;
            return change;
        } else {
            throw new IllegalArgumentException("Insufficient payment. Please provide the correct amount.");
        }
    }

    public void printReceipt(String paymentMethod, double change) {
        System.out.println("Receipt:");
        System.out.println("Cashier: " + getFirstName());
        System.out.println("Employee ID: " +getId());
        System.out.println("Items:");
        for (Product product : scannedItems) {
            System.out.println("- " + product.getProductName() + ": " + product.getPrice());
        }
        double totalAmount = calculateTotalAmount();
        System.out.println("Total amount: " + totalAmount);
        System.out.println("Payment method: " + paymentMethod);
        System.out.println("Change: " + change);
        System.out.println("Thank you for shopping with us!");
    }

    public void clearScannedItems() {
        scannedItems.clear();
    }
}

