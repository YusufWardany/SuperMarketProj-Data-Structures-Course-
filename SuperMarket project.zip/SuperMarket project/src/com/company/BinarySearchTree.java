package com.company;
import  java.util.* ;
public class BinarySearchTree<U>{

    public int key ;
    public TreeNode root ;
    public BinarySearchTree(){
        this.root = null ;
    }
    public BinarySearchTree(int value){
        this.root = new TreeNode(value) ;
    }
    public TreeNode getRoot() {
        return root;
    }
    public TreeNode search(TreeNode root , int key){
        if(root == null || root.data == key   )
            return root ;
        if(root.data < key){
            return search(root.right , key) ;
        }
        return search(root.left , key ) ;
    }
    public boolean search (int key){
        TreeNode result = search(root , key) ;
        if(result == null){
            return false ;
        }
        return true ;
    }
    public TreeNode insert(TreeNode node , int item ){
        if(node == null){
            return new TreeNode(item);
        }
        if(item < node.data)
            node.left = insert(node.left , item) ;
        else if(item > node.data)
            node.right = insert(node.right , item) ;
        return node ;
    }
    public void insert(int item){
        root = insert(root , item) ;
    }
    public void inorder(TreeNode root){
        if(root != null){
            inorder(root.left) ;
            System.out.print(root.data+" ");
            inorder(root.right) ;
        }


    }
    public void preorder(TreeNode root){
        if(root != null){
            System.out.print(root.data+" ");
            preorder(root.left);
            preorder(root.right);
        }

    }

    public void postorder(TreeNode root){
        if(root != null){
            preorder(root.left);
            postorder(root.right);
            System.out.print(root.data+" ");
        }

    }



    public TreeNode findMinimum(TreeNode node){
        if(node == null)
            return null ;
        else if(node.left == null){
            return node ;
        } else
            return findMinimum(node.left) ;
    }





    public TreeNode findMaximum(TreeNode node){
        if(node == null)
            return null ;
        else if(node.right == null){
            return node ;
        }else
            return findMaximum(node.right) ;
    }





    public TreeNode delete(TreeNode node , int key ){
        if(node == null){ // empty tree
            return null;
        }
        if(key < node.data) // item exist in left subtree
            node.left = delete(node.left , key) ;
        else if(key > node.data) // item exist in right subtree
            node.right = delete(node.right , key) ;
        else{
            if(node.left == null && node.right == null)//leaf node
                node = null;
            else if (node.left != null && node.right == null) { // one child on left
                node.data = node.left.data ;
                node.left = null  ;
            }
            else if(node.right != null && node.left == null){// one child on right
                node.data = node.right.data;
                node.right = null ;

            }
            else// node have two children
            {
                TreeNode predecessor_max = findMaximum(node.left) ;
                node.data = predecessor_max.data ;
                node.left = delete( node.left , predecessor_max.data) ;
            }

        }
        return node ;
    }
    public int findHeight(TreeNode root){ // number of edges in longer path from root to leaf node
        if(root.right == null && root.left == null)
            return 0 ;
        if(root == null)
            return -1 ;
        return Math.max(findHeight(root.left) , findHeight(root.right) ) + 1 ;


    }
    public int sumOfLeafNodes(TreeNode node){
        if(node == null)
            return 0 ;
        if(node.left == null && node.right == null)
            return node.data ;
        return sumOfLeafNodes(node.left) + sumOfLeafNodes(node.right) ;
    }


}
