package com.company;
import java.util.LinkedList;
public class Clothes extends  Product{
    private double price;
    private String size ;
    private String color ;
    private String material ;
    private String seasonality ;
    private String brandName;
    private LinkedList<Clothes> clothes ;
    public Clothes(){
        super();
        this.clothes = new LinkedList() ;
    }
    public Clothes(String productName,String ID,double price, String productionCountry, String supplierInformation, String size,
                   String color, String material, String seasonality, String brandName) {
        super(productName,ID, productionCountry, supplierInformation);
        this.price=price;
        this.size = size;
        this.color = color;
        this.material = material;
        this.seasonality = seasonality;
        this.brandName = brandName;
    }



    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getSeasonality() {
        return seasonality;
    }

    public void setSeasonality(String seasonality) {
        this.seasonality = seasonality;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }
    public void addClothes(String productName,String ID, String productionCountry, String supplierInformation, String size,
                           String color, String material, String seasonality, String brandName ){
        this.clothes.add(new Clothes(productName ,ID,price, productionCountry , supplierInformation , size ,
                color , material , seasonality , brandName));
    }
    public void removeClothesById(String ID){
        Clothes c = new Clothes() ;
        for(int i =  0 ; i < this.clothes.size() ; i++){
            if(this.clothes.get(i).getID().equalsIgnoreCase(ID)){
                this.clothes.remove(i) ;
            }
        }

    }

    public LinkedList<Clothes> getClothes() {
        return clothes;
    }

    public void setClothes(LinkedList<Clothes> clothes) {
        this.clothes = clothes;
    }
}
