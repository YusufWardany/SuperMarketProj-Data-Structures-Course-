package com.company;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Receipt {
    Product product1=new Product();
    private ArrayList<Product> products;

    public Receipt() {
        this.products =new ArrayList<Product>();
    }

    public void addProduct(Product i) {
        products.add(i);
    }

    public double calculateTotalAmount() {
        double totalAmount = 0.0;
        for (Product i : products) {
            totalAmount += i.getPrice();
        }
        return totalAmount;
    }

    public void printReceipt() {
        System.out.println("Receipt:)");
        System.out.println("products:");
        for (Product i : products) {
            System.out.println("- " + i.getProductName() + ": " + i.getPrice());
        }
        double totalAmount = calculateTotalAmount();
        System.out.println("Total amount: " + totalAmount);
        System.out.println("Thank you for shopping with us!");
    }
    public void addProductToCart(){
        Scanner console = new Scanner(System.in) ;
        Product p = new Product() ;
        Grocery g = new Grocery();
        Clothes c = new Clothes() ;
        MeatProducts m = new MeatProducts();
        Receipt receipt=new Receipt();
        ArrayList listOfSimpleMenu=new ArrayList();

        while (true){
            display();
            System.out.print("Choose a service:");
            int choice=console.nextInt();
            switch (choice){
                case 1: //Adding
                    System.out.print("Add a product:");
                    String elementToBeAdded=console.next();
                    listOfSimpleMenu.add(elementToBeAdded);
                    System.out.println("product has been added");
                    break;

                case 2: //Removing
                    System.out.print("Enter a product to be removed:");
                    String elementToBeRemoved=console.next();
                    if(listOfSimpleMenu.contains(elementToBeRemoved)){
                        listOfSimpleMenu.remove(elementToBeRemoved);
                        System.out.println("product has been removed");
                    }else {
                        System.out.println("product isn't existed");
                    }
                    break;

                case 3:  //Printing
                    System.out.println(listOfSimpleMenu);
                    break;

                case 4:
                    System.out.println("Exit");
                    return;
            }



        }

    }    static void display(){
        Scanner cons=new Scanner(System.in);
        System.out.println();
        System.out.println(
                "1.Add to cart\n"+
                        "2.Remove from cart\n"+
                        "3.print products\n"+
                        "4.Exit"
        );
        System.out.println();
    }
}
