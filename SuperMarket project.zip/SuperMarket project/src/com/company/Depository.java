package com.company;
import java.util.HashMap;
import java.util.Map;
public class Depository {
    private Map<String, Integer> Product;
    public Depository() {
        Product = new HashMap();}


    // Method to check the availability of a product
    public boolean checkAvailability(String productName, int quantity) {
        if (Product.containsKey(productName)) {
            int availableQuantity = Product.get(productName);
            return availableQuantity >= quantity;
        } else {
            System.out.println("Product '" + productName + "' not found in the depository.");
            return false;
        }
    }

    // Method to update Products after a purchase
    public void updateProduct(String productName, int quantity) {
        if (Product.containsKey(productName)) {
            int availableQuantity = Product.get(productName);
            Product.put(productName, availableQuantity - quantity);
            System.out.println("Stock updated for product '" + productName + "'.");
        } else {
            System.out.println("Product '" + productName + "' not found in the depository.");
        }
    }
        // Method to remove a specified quantity of a product from the stock
        public void removeProduct(String productName, int quantity) {
            if (Product.containsKey(productName)) {
                int availableQuantity = Product.get(productName);
                if (availableQuantity >= quantity) {
                    Product.put(productName, availableQuantity - quantity);
                    System.out.println("Removed " + quantity + " " + productName + " from the depository.");
                } else {
                    System.out.println("Not enough " + productName + " in the depository.");
                }
            } else {
                System.out.println("Product '" + productName + "' not found in the depository.");
            }
        }
    public void displayProducts(){
        Grocery g1=new Grocery();
        Clothes c1=new Clothes();
        ElectronicsProducts e1=new ElectronicsProducts();
        MeatProducts m1=new MeatProducts();
        System.out.println("Products:- ");

        System.out.println("Grocery products:");

        System.out.println("Fruits");
        for(int i = 0; i < g1.getFruits().size(); i++){
            System.out.println("Product "+(i+1)+" :");
            System.out.println("Product Name : "+g1.getProductName()+"\n"
                    +"Production Country : "+g1.getProductionCountry()+"\n"
                    +"Supplier Information : "+g1.getSupplierInformation()+"\n");
        }
        System.out.println();
        System.out.println("Vegetables");
        for(int i = 0; i < g1.getFruits().size(); i++){
            System.out.println("Product "+(i+1)+" :");
            System.out.println("Product Name : "+g1.getProductName()+"\n"
                    +"Production Country : "+g1.getProductionCountry()+"\n"
                    +"Supplier Information : "+g1.getSupplierInformation()+"\n");
        }
        System.out.println();



        System.out.println("Electronics products:");
        for(int i = 0; i < e1.getElectronics().size(); i++){
            System.out.println("Product "+(i+1)+" :");
            System.out.println("Product Name : "+e1.getProductName()+"\n"
                    +"Production Country : "+e1.getProductionCountry()+"\n"
                    +"Supplier Information : "+e1.getSupplierInformation()+"\n");
        }
        System.out.println();

        System.out.println("Clothes products:");
        for(int i = 0; i < c1.getClothes().size(); i++){
            System.out.println("Product "+(i+1)+" :");
            System.out.println("Product Name : "+c1.getProductName()+"\n"
                    +"Production Country : "+c1.getProductionCountry()+"\n"
                    +"Supplier Information : "+c1.getSupplierInformation()+"\n");
        }


    }

}



